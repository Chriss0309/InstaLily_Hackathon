"""Median ensemble of ['c', 'q2'] for social_contagion (built by scratchpad N/ensemble.py)."""
import importlib.util
import json
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
FAMILY = "social_contagion"
MEMBERS = ['c', 'q2']
_loaded = None


def _load():
    global _loaded
    if _loaded is None:
        _loaded = []
        for name in MEMBERS:
            spec = importlib.util.spec_from_file_location("ens_" + name, os.path.join(HERE, "v_" + name + ".py"))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            p = mod.load_params(FAMILY, os.path.join(HERE, "v_" + name + ".json"))
            _loaded.append((mod, p))
    return _loaded


def _median(xs):
    xs = sorted(xs)
    n = len(xs)
    return xs[n // 2] if n % 2 else 0.5 * (xs[n // 2 - 1] + xs[n // 2])


def simulate(fam, initial, actions, p=None):
    runs = []
    for mod, pm in _load():
        try:
            tr = mod.simulate(FAMILY, initial, actions, pm)
            if len(tr) == len(actions):
                runs.append(tr)
        except Exception:
            pass
    names = list(initial)
    if not runs:
        return [{k: float(initial[k]) for k in names} for _ in actions]
    out = []
    for t in range(len(actions)):
        row = {}
        for k in names:
            vals = [r[t][k] for r in runs if isinstance(r[t].get(k), (int, float)) and math.isfinite(r[t][k])]
            row[k] = float(_median(vals)) if vals else float(initial[k])
        out.append(row)
    return out


def load_params(fam, path=None):
    return {}


def predict(initial, interventions, context=None):
    try:
        out = simulate(FAMILY, initial, list(interventions))
    except Exception:
        out = [{k: float(initial[k]) for k in initial} for _ in interventions]
    obs = None
    if context is not None and hasattr(context, "get"):
        obs = context.get("observables")
    names = list(obs) if obs else list(initial)
    return [{k: float(r.get(k, initial.get(k, 0.0))) for k in names} for r in out]
